package com.example.calendarwidget.data

/**
 * Model representing an individual calendar event instance.
 */
data class CalendarEventModel(
    val id: Long,
    val title: String,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val startTimeString: String,
    val isAllDay: Boolean,
    val displayColor: Int
)

/**
 * Model representing a single day column within the 7-day week.
 */
data class DayScheduleData(
    val dayIndex: Int,
    val dateKey: String,
    val dayAbbr: String,
    val dayNumber: Int,
    val isToday: Boolean,
    val allDayEvents: List<CalendarEventModel>,
    val timedEvents: List<CalendarEventModel>
)

/**
 * Model representing the entire week layout.
 */
data class WeekSchedule(
    val monthYearTitle: String,
    val days: List<DayScheduleData>,
    val isEmptyWeek: Boolean
)