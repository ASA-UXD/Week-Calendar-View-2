package com.example.calendarwidget.widget.ui

import android.content.ContentUris
import android.content.Intent
import android.provider.CalendarContract
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.ColorUtils
import androidx.glance.GlanceModifier
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.color.ColorProvider
import androidx.glance.layout.Column
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.padding
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import com.example.calendarwidget.data.CalendarEventModel

/**
 * Event card inside a day column.
 * - Corner radius: 4dp (as requested)
 * - Background color: CalendarContract event color or calendar color
 * - Luminance check: automatic white or dark text for accessibility
 * - Tap interaction: Launches native Google Calendar directly to the event view
 */
@Composable
fun EventPillView(
    event: CalendarEventModel,
    isAllDay: Boolean,
    modifier: GlanceModifier = GlanceModifier
) {
    // Exact intent to open the event in Google Calendar / System Calendar
    val viewEventIntent = Intent(Intent.ACTION_VIEW).apply {
        data = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, event.id)
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }

    // Determine readable foreground color based on background luminance
    // ColorUtils.calculateLuminance returns a double between 0.0 (black) and 1.0 (white)
    val luminance = ColorUtils.calculateLuminance(event.displayColor)
    val textColor = if (luminance > 0.45) Color(0xFF1F1F1F) else Color(0xFFFFFFFF)

    Column(
        modifier = modifier
            .fillMaxWidth()
            .cornerRadius(4.dp)
            .background(ColorProvider(Color(event.displayColor)))
            .clickable(actionStartActivity(viewEventIntent))
            .padding(horizontal = 3.dp, vertical = 2.dp)
    ) {
        // Event title
        Text(
            text = event.title,
            maxLines = 1,
            style = TextStyle(
                color = ColorProvider(textColor),
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        )

        // Event time string (only for timed events)
        if (!isAllDay && event.startTimeString.isNotEmpty()) {
            Text(
                text = event.startTimeString,
                maxLines = 1,
                style = TextStyle(
                    color = ColorProvider(textColor.copy(alpha = 0.85f)),
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Normal
                )
            )
        }
    }
}