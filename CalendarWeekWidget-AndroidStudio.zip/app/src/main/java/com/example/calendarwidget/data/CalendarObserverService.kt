package com.example.calendarwidget.data

import android.app.Service
import android.content.Context
import android.content.Intent
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.CalendarContract
import androidx.glance.appwidget.GlanceAppWidgetManager
import com.example.calendarwidget.widget.CalendarWeekWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Service that maintains a [ContentObserver] listening to changes in [CalendarContract.Events.CONTENT_URI].
 * Whenever an event is created, edited, or deleted in Google Calendar or any other calendar sync adapter,
 * this observer triggers a refresh for all active instances of [CalendarWeekWidget].
 */
class CalendarObserverService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var calendarObserver: ContentObserver? = null

    override fun onCreate() {
        super.onCreate()
        registerCalendarObserver()
    }

    private fun registerCalendarObserver() {
        calendarObserver = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean, uri: Uri?) {
                super.onChange(selfChange, uri)
                // Debounce / trigger widget update
                serviceScope.launch {
                    val manager = GlanceAppWidgetManager(applicationContext)
                    val glanceIds = manager.getGlanceIds(CalendarWeekWidget::class.java)
                    val widget = CalendarWeekWidget()
                    glanceIds.forEach { id ->
                        widget.update(applicationContext, id)
                    }
                }
            }
        }

        // Register to observe changes to events
        contentResolver.registerContentObserver(
            CalendarContract.Events.CONTENT_URI,
            true,
            calendarObserver!!
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        calendarObserver?.let {
            contentResolver.unregisterContentObserver(it)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        fun startObserving(context: Context) {
            val intent = Intent(context, CalendarObserverService::class.java)
            context.startService(intent)
        }

        fun stopObserving(context: Context) {
            val intent = Intent(context, CalendarObserverService::class.java)
            context.stopService(intent)
        }
    }
}