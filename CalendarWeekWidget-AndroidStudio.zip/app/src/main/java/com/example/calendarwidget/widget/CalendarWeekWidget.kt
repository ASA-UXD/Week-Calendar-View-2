package com.example.calendarwidget.widget

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.DpSize
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Box
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.padding
import com.example.calendarwidget.data.CalendarRepository
import com.example.calendarwidget.data.WeekSchedule
import com.example.calendarwidget.widget.ui.PermissionPromptView
import com.example.calendarwidget.widget.ui.WeekWidgetContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * High-performance Week View Calendar Widget built on Jetpack Glance.
 * Mimics native Google Calendar with:
 * - 7-day column grid
 * - Dynamic Material You theming
 * - CalendarContract event sync
 * - Contrast-aware event pills
 */
class CalendarWeekWidget : GlanceAppWidget() {

    // Define responsive sizes for responsive widget layouts
    override val sizeMode: SizeMode = SizeMode.Responsive(
        setOf(
            DpSize(250.dp, 120.dp), // Compact (e.g. 4x2)
            DpSize(320.dp, 200.dp), // Standard (e.g. 4x3)
            DpSize(400.dp, 280.dp)  // Expanded (e.g. 5x4 or Foldables)
        )
    )

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        // Asynchronously check permission and fetch events using Kotlin Coroutines
        val hasPermission = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CALENDAR
        ) == PackageManager.PERMISSION_GRANTED

        val repository = CalendarRepository(context)
        val weekSchedule: WeekSchedule? = if (hasPermission) {
            withContext(Dispatchers.IO) {
                repository.getCurrentWeekSchedule()
            }
        } else {
            null
        }

        provideContent {
            GlanceTheme {
                WidgetRoot(
                    hasPermission = hasPermission,
                    weekSchedule = weekSchedule
                )
            }
        }
    }

    @Composable
    private fun WidgetRoot(
        hasPermission: Boolean,
        weekSchedule: WeekSchedule?
    ) {
        Box(
            modifier = GlanceModifier
                .fillMaxSize()
                .background(GlanceTheme.colors.surface)
                .padding(8.dp)
        ) {
            if (!hasPermission) {
                // When permission is not granted, render the Material 3 prompt view
                PermissionPromptView()
            } else if (weekSchedule != null) {
                // Render the complete 7-day week view grid
                WeekWidgetContent(weekSchedule = weekSchedule)
            }
        }
    }
}