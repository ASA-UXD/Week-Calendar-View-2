package com.example.calendarwidget.widget.ui

import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.appwidget.cornerRadius
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import com.example.calendarwidget.data.DayScheduleData

/**
 * Single day column in the 7-day week grid.
 * Features:
 * - Day abbreviation (M, T, W, T, F, S, S)
 * - Date number in circular badge (filled with Primary color for today)
 * - All-day events block
 * - Timed events list with smart truncating/stacking
 */
@Composable
fun DayColumnView(
    dayData: DayScheduleData,
    modifier: GlanceModifier = GlanceModifier
) {
    Column(
        modifier = modifier
            .fillMaxHeight()
            .padding(horizontal = 1.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // --- 1. Day of week initial (e.g. M, T, W) ---
        Text(
            text = dayData.dayAbbr,
            style = TextStyle(
                color = if (dayData.isToday) GlanceTheme.colors.primary else GlanceTheme.colors.onSurfaceVariant,
                fontSize = 11.sp,
                fontWeight = if (dayData.isToday) FontWeight.Bold else FontWeight.Normal,
                textAlign = TextAlign.Center
            )
        )

        Spacer(modifier = GlanceModifier.height(2.dp))

        // --- 2. Day Number (Highlighted circle if Today) ---
        Box(
            modifier = GlanceModifier
                .size(24.dp)
                .cornerRadius(12.dp)
                .background(
                    if (dayData.isToday) GlanceTheme.colors.primary else GlanceTheme.colors.surfaceVariant
                ),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = dayData.dayNumber.toString(),
                style = TextStyle(
                    color = if (dayData.isToday) GlanceTheme.colors.onPrimary else GlanceTheme.colors.onSurface,
                    fontSize = 12.sp,
                    fontWeight = if (dayData.isToday) FontWeight.Bold else FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            )
        }

        Spacer(modifier = GlanceModifier.height(4.dp))

        // --- 3. Events Stack (All-day first, then timed events) ---
        Column(
            modifier = GlanceModifier
                .fillMaxWidth()
                .fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Render all-day events pinned at top
            dayData.allDayEvents.take(2).forEach { event ->
                EventPillView(
                    event = event,
                    isAllDay = true
                )
                Spacer(modifier = GlanceModifier.height(2.dp))
            }

            // Render timed events
            dayData.timedEvents.take(3).forEach { event ->
                EventPillView(
                    event = event,
                    isAllDay = false
                )
                Spacer(modifier = GlanceModifier.height(2.dp))
            }

            // If more events exist than fit widget display
            val remainingCount = (dayData.allDayEvents.size + dayData.timedEvents.size) - 5
            if (remainingCount > 0) {
                Text(
                    text = "+$remainingCount more",
                    style = TextStyle(
                        color = GlanceTheme.colors.onSurfaceVariant,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Medium
                    ),
                    modifier = GlanceModifier.padding(top = 1.dp)
                )
            }
        }
    }
}